#Nightlife Web App
It's a responsive fullstack web application using React, Redux, Mongo.db, Node.js, Passport lib. for authentication, Mocha for testing and newest css features as Grid system to being full responsive across different devices, also Canvas for animations.
