import React from 'react';

const Background = () => {
  return (
    <div className="wrapper">
      <div className="bgFoggy"></div>
    </div>
  )
}

export default Background;
