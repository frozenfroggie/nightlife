import { TOOGLE_EXPAND_MENU } from '../../../constants/actionTypes';

export const toogleExpandMenu = () => ({
  type: TOOGLE_EXPAND_MENU
});
