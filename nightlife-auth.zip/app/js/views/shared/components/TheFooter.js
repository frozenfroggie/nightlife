import React from 'react';

const Footer = () => {
  return (
    <footer>
      <span> Designed & Coded by FrozenFroggie </span>
      <span> 2017 &reg; All rights reserved </span>
    </footer>
  )
}

export default Footer;
